# Introduction 
Project name: resaurant booking

this project is designed to link a sql database between a front end website and a backend codebase

members: michael alex bryant, devon painton, levi delaney , logan farquhar.

languages this project will use: c#, sql, html, css.

this project must be completed within 6 weeks of starting 
and must be approved by the product owner before beginning
